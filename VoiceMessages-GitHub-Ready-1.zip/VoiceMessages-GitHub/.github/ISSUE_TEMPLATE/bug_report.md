---
name: Bug Report
about: Report a bug or issue with VoiceMessages
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description
A clear and concise description of what the bug is.

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. Record a message '...'
4. See error

## Expected Behavior
What you expected to happen.

## Actual Behavior
What actually happened.

## Screenshots/Recordings
If applicable, add screenshots or screen recordings to help explain your problem.

## Environment
- **Android Version:** (e.g., Android 13)
- **Device:** (e.g., Samsung Galaxy S21)
- **Discord Version:** (e.g., 180.14)
- **Aliucord Version:** (e.g., 1.1.0)
- **VoiceMessages Version:** (e.g., 1.0.0)
- **Quality Preset:** (e.g., Ultra Lossless)

## Error Messages
If you see any error messages or toasts, include them here.

## Additional Context
Add any other context about the problem here.

## Possible Solution
If you have ideas on how to fix this, share them here (optional).
