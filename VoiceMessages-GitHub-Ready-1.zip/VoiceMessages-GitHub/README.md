# VoiceMessages Plugin for Aliucord

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://github.com/yourusername/VoiceMessages/releases)
[![Quality](https://img.shields.io/badge/audio-lossless%2096kHz%2F24bit-green.svg)](https://github.com/yourusername/VoiceMessages)

> Record and send ultra-high quality voice messages in Discord - now with **lossless studio-grade audio**!

## ✨ Features

> **TL;DR:** Tap 🎤 to record, tap ⏹️ to send. Simple as that!

### Quick Start
1. Install plugin in Aliucord
2. Grant microphone & storage permissions
3. Tap 🎤 button in any chat
4. Record your message
5. Tap ⏹️ to stop and send

---

## 🎵 Features

- 🎤 Record voice messages directly from the chat input
- ⏹️ Stop recording with a single tap
- 🎵 **Ultra-high quality recording** (Lossless WAV, 96kHz/24-bit, Stereo) - DEFAULT
- 🎧 Studio Master quality option (192kHz/24-bit) for absolute maximum fidelity
- 💿 Lossless audio - NO compression, perfect quality preservation
- 📤 Automatic file upload to Discord
- ⏱️ Recording duration display
- 🔊 Audio preview with duration in message

## 📸 Screenshots

<!-- Add your screenshots here when available -->
*Coming soon! Show off that 🎤 button and beautiful lossless audio quality*

## 📥 Installation

1. Download the `.zip` file from the releases
2. Open Aliucord and navigate to Plugins
3. Click the "Install from File" button
4. Select the downloaded `.zip` file
5. Enable the VoiceMessages plugin

## Usage

1. Open any Discord chat
2. Look for the 🎤 microphone icon in the chat input area
3. Tap to start recording (icon changes to ⏹️)
4. Tap again to stop recording
5. The voice message will be ready to send

## Permissions

This plugin requires the following permissions:
- **RECORD_AUDIO**: To record voice messages
- **WRITE_EXTERNAL_STORAGE**: To save recordings
- **READ_EXTERNAL_STORAGE**: To read recordings for playback

Make sure these permissions are granted when prompted.

## Building from Source

1. Clone this repository
2. Place it in your Aliucord plugins directory
3. Build using the Aliucord plugin build system:
   ```
   ./gradlew make
   ```

## Project Structure

```
VoiceMessages/
├── src/main/java/com/aliucord/plugins/
│   └── VoiceMessages.java
├── AndroidManifest.xml
├── build.gradle
└── README.md
```

## TODO / Future Improvements

- [ ] Add playback controls for received voice messages
- [ ] Add waveform visualization during recording
- [ ] Add visual recording timer in UI
- [ ] Add settings for audio quality
- [ ] Add long-press to record gesture
- [ ] Add voice message preview before sending
- [ ] Add ability to cancel recording
- [ ] Add support for other audio formats (OGG, OPUS)

## Technical Details

### Audio Quality Presets

| Quality | Format | Bitrate/Depth | Sample Rate | Channels | Use Case | Avg File Size* |
|---------|--------|---------------|-------------|----------|----------|----------------|
| Low | AAC | 64 kbps | 44.1 kHz | Mono | Data saving | ~480 KB/min |
| Standard | AAC | 128 kbps | 44.1 kHz | Stereo | Balanced | ~960 KB/min |
| High | AAC | 192 kbps | 48 kHz | Stereo | Clear speech | ~1.4 MB/min |
| Professional | AAC | 320 kbps | 48 kHz | Stereo | Music quality | ~2.4 MB/min |
| Ultra (AAC) | AAC | 320 kbps | 96 kHz | Stereo | Hi-Res compressed | ~2.9 MB/min |
| **Ultra (Lossless)** | **WAV** | **24-bit** | **96 kHz** | **Stereo** | **Studio quality** | **~27 MB/min** |
| **Studio Master** | **WAV** | **24-bit** | **192 kHz** | **Stereo** | **Absolute maximum** | **~55 MB/min** |

*File sizes are approximate

**Default setting:** Ultra (Lossless) for perfect, uncompressed audio quality.  
**Change in settings:** Plugin Settings → Audio Quality

### What is Lossless?

Lossless audio means the recording is stored with **ZERO quality loss** - every single sound wave is preserved perfectly. This is the same quality used in:
- Professional recording studios
- Music mastering
- Archival recordings
- Audiophile playback

The trade-off is much larger file sizes, but you get absolutely perfect audio.

### Recording
- Uses `AudioRecord` for lossless WAV recording (Ultra/Studio Master)
- Uses `MediaRecorder` for compressed AAC recording (Low-Professional)
- Lossless: 24-bit PCM WAV at 96kHz or 192kHz, Stereo
- Compressed: AAC format (M4A) with configurable bitrates
- Files stored in app's external music directory
- Quality surpasses CD audio (16-bit/44.1kHz)

### Lossless vs Compressed
**Lossless (WAV):**
- Perfect audio reproduction
- 24-bit depth captures incredible dynamic range
- 96/192kHz sample rate captures ultrasonic detail
- 10-20x larger files
- Ideal for: music, singing, archival, professional use

**Compressed (AAC):**
- Smaller file sizes
- Still excellent quality at 320 kbps
- Faster uploads
- Ideal for: speech, casual voice messages, mobile data

### File Upload
- Uses Discord's `RestAPI.getApi().sendMessage()` with attachments
- Gets current channel ID from `StoreStream.getChannelsSelected().getId()`
- Calculates audio duration using `MediaPlayer` before upload
- Sends message with format: "🎤 Voice Message (duration)"
- Automatic file cleanup after successful upload

### UI Integration
- Patches `WidgetChatInput` to add microphone button
- Button toggles between 🎤 (ready) and ⏹️ (recording)
- Shows toast notifications for recording state changes
- Displays recording duration when stopped

## Notes

✅ **Implementation Complete**: The plugin now includes full functionality for:
- Recording audio using MediaRecorder
- Uploading files to Discord using RestAPI
- Getting the current channel ID from StoreStream
- Displaying recording duration in the sent message
- Automatic cleanup of local files after upload

The plugin uses Discord's native file attachment API to send voice messages as audio files with duration information.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License.

## Credits

Created for Aliucord - The Android Discord client modification framework

## 📚 Documentation

- **[Quick Reference](QUICK_REFERENCE.md)** - Fast commands and settings
- **[Setup Guide](SETUP_GUIDE.md)** - Detailed build and installation instructions  
- **[Ultra Quality Guide](ULTRA_QUALITY_GUIDE.md)** - Everything about audio quality
- **[Installation Guide](INSTALLATION.md)** - Troubleshooting and setup
- **[Contributing](CONTRIBUTING.md)** - How to contribute to this project
- **[Changelog](CHANGELOG.md)** - Version history and updates

## 🔗 Links

- [Report a Bug](../../issues/new?template=bug_report.md)
- [Request a Feature](../../issues/new?template=feature_request.md)
- [View Releases](../../releases)
- [Aliucord](https://github.com/Aliucord/Aliucord)

## ⭐ Star This Project

If you find this plugin useful, please consider giving it a star! It helps others discover it.

## 🤝 Contributing

Contributions are welcome! Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details on how to contribute.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

<p align="center">
  Made with ❤️ for the Aliucord community<br>
  <sub>Record with passion, share with quality</sub>
</p>
