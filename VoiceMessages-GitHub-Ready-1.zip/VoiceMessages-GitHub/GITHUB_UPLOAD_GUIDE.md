# How to Upload VoiceMessages to GitHub

## Quick Method (Easiest)

### Step 1: Create Repository on GitHub
1. Go to https://github.com
2. Click the "+" in top right → "New repository"
3. Repository name: `VoiceMessages`
4. Description: `Ultra-high quality voice messages for Discord (Aliucord plugin)`
5. **Make it Public** (or Private if you prefer)
6. **DO NOT** check "Add a README" (we already have one)
7. Click "Create repository"

### Step 2: Prepare Your Files

Extract `VoiceMessages-plugin.zip` to get the VoiceMessages folder with this structure:
```
VoiceMessages/
├── src/
│   └── main/
│       ├── java/com/aliucord/plugins/
│       │   ├── VoiceMessages.java
│       │   └── VoiceMessagesSettings.java
│       └── AndroidManifest.xml
├── build.gradle
└── README.md
```

### Step 3A: Upload via Web (Simplest)

1. On your new GitHub repository page, click "uploading an existing file"
2. Drag and drop ALL the files and folders from the VoiceMessages folder
3. Make sure to maintain the folder structure
4. Add commit message: "Initial commit: VoiceMessages v1.0.0"
5. Click "Commit changes"

Done! ✅

### Step 3B: Upload via Command Line (Recommended)

Open terminal/command prompt in the VoiceMessages folder:

```bash
# Initialize Git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit: VoiceMessages v1.0.0"

# Connect to GitHub (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/VoiceMessages.git

# Push to GitHub
git branch -M main
git push -u origin main
```

Done! ✅

## After Upload

### Add Topics (Tags)
1. Go to your repository on GitHub
2. Click the gear icon ⚙️ next to "About"
3. Add topics: `aliucord`, `discord`, `android`, `plugin`, `voice-messages`, `audio`, `lossless`
4. Save changes

### Create a Release (Optional but Recommended)

If you want people to easily download your plugin:

1. Go to your repository
2. Click "Releases" → "Create a new release"
3. Click "Choose a tag" → Type `v1.0.0` → Create new tag
4. Release title: `VoiceMessages v1.0.0 - Ultra Quality Voice Messages`
5. Description:
   ```
   First release of VoiceMessages!
   
   Features:
   - Ultra Lossless quality (96kHz/24-bit WAV)
   - 7 quality presets
   - Simple tap-to-record interface
   - Studio-grade audio quality
   
   Download VoiceMessages.zip below and install via Aliucord.
   ```
6. Upload the built `VoiceMessages.zip` file (the one you install in Aliucord)
7. Click "Publish release"

Now people can download your plugin directly from the releases page!

## Troubleshooting

### "Permission denied (publickey)"
You need to set up SSH keys or use HTTPS with a personal access token.

**Quick fix**: Use GitHub Desktop instead:
1. Download GitHub Desktop: https://desktop.github.com
2. File → New Repository → Choose existing folder
3. Select your VoiceMessages folder
4. Click "Publish repository"

### "Failed to push"
Make sure:
- You're using the correct repository URL
- You have permission to push to the repository
- The repository name matches exactly

### Files not showing up
Check your folder structure - make sure you're uploading the contents of the VoiceMessages folder, not wrapping it in another folder.

## What People Will See

When someone visits your GitHub repository, they'll see:
- Your README with features and instructions
- The source code organized in folders
- Option to download/clone
- If you created a release: Easy download button

## Keeping It Updated

When you make changes:
```bash
git add .
git commit -m "Description of what you changed"
git push
```

---

**That's it! Your plugin is now on GitHub!** 🚀

## Quick Reference

**Repository URL format**: `https://github.com/YOUR_USERNAME/VoiceMessages`

**Clone command**: `git clone https://github.com/YOUR_USERNAME/VoiceMessages.git`

**Your repo link**: Replace YOUR_USERNAME with your GitHub username in the URL above!
