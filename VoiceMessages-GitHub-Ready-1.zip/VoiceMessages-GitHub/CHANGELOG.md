# Changelog

All notable changes to VoiceMessages will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned
- Waveform visualization during recording
- Voice message playback controls in chat
- Recording pause/resume functionality
- Cancel recording option
- OPUS codec support

## [1.0.0] - 2025-02-14

### Added
- Initial release
- Ultra-high quality lossless recording (96kHz/24-bit WAV)
- Studio Master quality option (192kHz/24-bit WAV)
- 7 quality presets from Low to Studio Master
- Automatic file upload to Discord
- Recording duration display
- File size display in messages
- Settings page for quality selection
- Support for both compressed (AAC) and lossless (WAV) formats
- Stereo recording support
- Professional-grade audio quality
- Microphone button in chat input
- Toast notifications for recording state
- Error handling for permissions and recording issues
- Automatic file cleanup after upload

### Features
- **Quality Presets:**
  - Low: 64 kbps AAC, 44.1kHz, Mono
  - Standard: 128 kbps AAC, 44.1kHz, Stereo
  - High: 192 kbps AAC, 48kHz, Stereo
  - Professional: 320 kbps AAC, 48kHz, Stereo
  - Ultra (AAC): 320 kbps AAC, 96kHz, Stereo
  - Ultra (Lossless): 24-bit WAV, 96kHz, Stereo (DEFAULT)
  - Studio Master: 24-bit WAV, 192kHz, Stereo

### Technical
- Uses MediaRecorder for compressed AAC encoding
- Uses AudioRecord for lossless WAV recording
- Direct PCM capture with proper WAV headers
- Multi-threaded recording for smooth performance
- Integration with Discord's RestAPI for uploads
- StoreStream integration for channel management

### Documentation
- Complete README with feature list and technical specs
- SETUP_GUIDE for building and installation
- ULTRA_QUALITY_GUIDE with detailed quality explanations
- INSTALLATION guide with troubleshooting
- QUALITY_GUIDE with comparison tables
- QUICK_REFERENCE for fast lookups
- CONTRIBUTING guidelines
- Issue templates for bugs and features

### Known Limitations
- Lossless files are very large (27-55 MB/min)
- Free Discord users limited to ~18 seconds of lossless recording
- No playback controls for received voice messages yet
- No waveform visualization yet
- No recording preview before sending

---

## Version History

**[1.0.0]** - Initial release with full lossless support
- First public version
- Complete feature set
- All 7 quality presets working
- Full documentation

---

## Future Roadmap

### Version 1.1.0 (Planned)
- [ ] Waveform visualization
- [ ] Recording timer in UI
- [ ] Cancel recording button
- [ ] Voice message playback controls

### Version 1.2.0 (Planned)
- [ ] OPUS codec support
- [ ] Noise reduction
- [ ] Recording pause/resume
- [ ] Multiple file format export

### Version 2.0.0 (Future)
- [ ] Voice effects
- [ ] Transcription support
- [ ] Cloud backup integration
- [ ] Advanced audio processing

---

## Notes

- All dates in this changelog are in YYYY-MM-DD format
- This project follows [Semantic Versioning](https://semver.org/)
- For a detailed list of changes, see the [commit history](../../commits/main)
