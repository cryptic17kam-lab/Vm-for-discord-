# Contributing to VoiceMessages

First off, thank you for considering contributing to VoiceMessages! It's people like you that make this plugin better for everyone.

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check the existing issues to avoid duplicates. When you create a bug report, include as many details as possible:

- **Use a clear and descriptive title**
- **Describe the exact steps to reproduce the problem**
- **Provide specific examples** (screenshots, recordings if possible)
- **Describe the behavior you observed** and what you expected
- **Include details about your configuration:**
  - Android version
  - Discord version
  - Aliucord version
  - VoiceMessages version
  - Quality preset you're using

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion:

- **Use a clear and descriptive title**
- **Provide a detailed description** of the suggested enhancement
- **Explain why this enhancement would be useful** to most users
- **List any alternatives** you've considered

### Code Contributions

#### Development Setup

1. Fork the repository
2. Clone your fork: `git clone https://github.com/YOUR_USERNAME/VoiceMessages.git`
3. Set up the Aliucord development environment (see SETUP_GUIDE.md)
4. Create a branch: `git checkout -b feature/your-feature-name`

#### Coding Guidelines

- **Follow Java naming conventions**
- **Add comments for complex logic**
- **Keep functions focused and small**
- **Handle errors gracefully**
- **Test on multiple Android versions if possible**

#### Quality Checklist

Before submitting:
- [ ] Code compiles without errors
- [ ] Plugin installs successfully
- [ ] Basic functionality works (record, stop, send)
- [ ] No crashes or force closes
- [ ] Permissions are properly requested
- [ ] Memory leaks checked (recording stops properly)

#### Pull Request Process

1. **Update documentation** if you changed functionality
2. **Test thoroughly** on your device
3. **Update README.md** if you added features
4. **Create a pull request** with a clear description:
   - What changes you made
   - Why you made them
   - How to test them
   - Any breaking changes

### Commit Messages

Use clear, descriptive commit messages:

**Good:**
```
Add support for OGG Vorbis format
Fix memory leak when stopping lossless recording
Improve error handling for permission denials
```

**Bad:**
```
fix bug
update
changes
```

## Code of Conduct

### Our Standards

- **Be respectful** and inclusive
- **Welcome newcomers** and help them learn
- **Give and gracefully accept constructive feedback**
- **Focus on what is best** for the community

### Unacceptable Behavior

- Harassment, discriminatory comments
- Trolling, insulting/derogatory comments
- Public or private harassment
- Publishing others' private information

## Feature Requests

We love feature ideas! Here are some we're considering:

### High Priority
- [ ] Waveform visualization during recording
- [ ] Recording duration limit setting
- [ ] Cancel recording before sending
- [ ] Play button for voice messages in chat

### Medium Priority
- [ ] OPUS codec support (better compression)
- [ ] Noise reduction/enhancement
- [ ] Recording pause/resume
- [ ] Multiple recording quality quick-switch

### Low Priority
- [ ] Voice effects (pitch, speed)
- [ ] Transcription support
- [ ] Recording backup/export

Feel free to work on any of these or propose your own!

## Building and Testing

### Quick Build
```bash
cd /path/to/aliucord-plugins
./gradlew :VoiceMessages:make
```

### Testing Checklist
- [ ] Recording starts and stops properly
- [ ] File uploads successfully to Discord
- [ ] Permissions are requested correctly
- [ ] Settings page works
- [ ] Quality presets all work
- [ ] No crashes on rotation
- [ ] Proper cleanup on plugin disable

## Questions?

- **Open an issue** for bugs or feature requests
- **Check existing issues** before creating duplicates
- **Be patient** - this is maintained in free time

## Recognition

Contributors will be:
- Added to the README
- Credited in release notes
- Given our eternal gratitude! 🎉

---

**Thank you for making VoiceMessages better!** 🎵
