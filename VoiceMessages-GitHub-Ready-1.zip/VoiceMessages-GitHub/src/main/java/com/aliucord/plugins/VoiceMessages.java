package com.aliucord.plugins;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Environment;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.aliucord.Utils;
import com.aliucord.annotations.AliucordPlugin;
import com.aliucord.entities.Plugin;
import com.aliucord.fragments.SettingsPage;
import com.aliucord.patcher.*;
import com.aliucord.utils.DimenUtils;
import com.discord.models.domain.ModelMessage;
import com.discord.stores.StoreStream;
import com.discord.utilities.rest.RestAPI;
import com.discord.widgets.chat.input.ChatInputViewModel;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import kotlin.jvm.functions.Function1;
import rx.Observable;

@AliucordPlugin
public class VoiceMessages extends Plugin {
    private MediaRecorder mediaRecorder;
    private MediaPlayer mediaPlayer;
    private AudioRecord audioRecord;
    private Thread recordingThread;
    private boolean isRecordingLossless = false;
    private String currentRecordingPath;
    private boolean isRecording = false;
    private boolean isPlaying = false;
    private long recordingStartTime = 0;
    private TextView recordingTimerView;

    @NonNull
    @Override
    public Manifest getManifest() {
        Manifest manifest = new Manifest();
        manifest.authors = new Manifest.Author[]{ new Manifest.Author("YourName", 0L) };
        manifest.description = "Ultra-high quality voice messages (Lossless 96kHz/24-bit WAV)";
        manifest.version = "1.0.0";
        manifest.updateUrl = null;
        return manifest;
    }

    @Override
    public void start(Context context) {
        patchChatInput();
    }

    @Override
    public SettingsPage getSettingsPage() {
        return new VoiceMessagesSettings(settings);
    }

    @SuppressLint("SetTextI18n")
    private void patchChatInput() {
        // Add a button to the chat input for voice recording
        patcher.patch(
            "com.discord.widgets.chat.input.WidgetChatInput",
            "configureUI",
            new Hook(param -> {
                try {
                    View view = (View) param.thisObject;
                    LinearLayout layout = view.findViewById(Utils.getResId("input_layout", "id"));
                    
                    if (layout != null) {
                        // Create voice message button
                        TextView voiceButton = new TextView(layout.getContext());
                        voiceButton.setText(isRecording ? "⏹" : "🎤");
                        voiceButton.setTextSize(24);
                        voiceButton.setPadding(
                            DimenUtils.dpToPx(8),
                            DimenUtils.dpToPx(8),
                            DimenUtils.dpToPx(8),
                            DimenUtils.dpToPx(8)
                        );
                        
                        voiceButton.setOnClickListener(v -> {
                            if (isRecording) {
                                stopRecording();
                                sendVoiceMessage();
                                voiceButton.setText("🎤");
                            } else {
                                startRecording(layout.getContext());
                                voiceButton.setText("⏹");
                            }
                        });
                        
                        layout.addView(voiceButton, 0);
                    }
                } catch (Exception e) {
                    logger.error("Failed to patch chat input", e);
                }
            })
        );
    }

    private void startRecording(Context context) {
        try {
            // Get quality settings
            AudioQuality quality = getAudioQuality();
            
            // Create file for recording
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String extension = quality.lossless ? ".wav" : ".m4a";
            String fileName = "VOICE_" + timeStamp + extension;
            File storageDir = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC);
            
            if (storageDir != null && !storageDir.exists()) {
                storageDir.mkdirs();
            }
            
            File audioFile = new File(storageDir, fileName);
            currentRecordingPath = audioFile.getAbsolutePath();

            if (quality.lossless) {
                // Use AudioRecord for lossless WAV recording
                startLosslessRecording(quality);
            } else {
                // Use MediaRecorder for compressed AAC recording
                startCompressedRecording(quality);
            }

            isRecording = true;
            recordingStartTime = System.currentTimeMillis();

            String qualityInfo = quality.lossless 
                ? String.format(Locale.US, "%s - %d-bit/%dkHz", quality.name, quality.bitDepth, quality.sampleRate/1000)
                : String.format(Locale.US, "%s - %dkbps/%dkHz", quality.name, quality.bitrate/1000, quality.sampleRate/1000);
            Utils.showToast("🎤 Recording: " + qualityInfo);
            
        } catch (IOException e) {
            logger.error("Failed to start recording", e);
            Utils.showToast("❌ Failed to start recording: " + e.getMessage());
            isRecording = false;
        } catch (SecurityException e) {
            logger.error("Permission denied for recording", e);
            Utils.showToast("❌ Microphone permission required");
            isRecording = false;
        }
    }
    
    private void startCompressedRecording(AudioQuality quality) throws IOException {
        // Initialize MediaRecorder with quality settings
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        mediaRecorder.setOutputFile(currentRecordingPath);
        
        // Apply quality settings
        mediaRecorder.setAudioEncodingBitRate(quality.bitrate);
        mediaRecorder.setAudioSamplingRate(quality.sampleRate);
        mediaRecorder.setAudioChannels(quality.channels);

        mediaRecorder.prepare();
        mediaRecorder.start();
    }
    
    private void startLosslessRecording(AudioQuality quality) throws IOException {
        // Calculate buffer size for AudioRecord
        int channelConfig = quality.channels == 2 ? AudioFormat.CHANNEL_IN_STEREO : AudioFormat.CHANNEL_IN_MONO;
        int audioFormat = quality.bitDepth == 24 ? AudioFormat.ENCODING_PCM_FLOAT : AudioFormat.ENCODING_PCM_16BIT;
        
        int bufferSize = AudioRecord.getMinBufferSize(
            quality.sampleRate,
            channelConfig,
            audioFormat
        ) * 4; // 4x buffer for safety

        // Initialize AudioRecord
        audioRecord = new AudioRecord(
            MediaRecorder.AudioSource.MIC,
            quality.sampleRate,
            channelConfig,
            audioFormat,
            bufferSize
        );

        if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
            throw new IOException("AudioRecord initialization failed");
        }

        // Create WAV file with header
        createWavHeader(currentRecordingPath, quality);

        // Start recording thread
        isRecordingLossless = true;
        audioRecord.startRecording();
        
        recordingThread = new Thread(() -> {
            writeWavData(quality, bufferSize);
        });
        recordingThread.start();
    }
    
    private void createWavHeader(String filePath, AudioQuality quality) throws IOException {
        FileOutputStream fos = new FileOutputStream(filePath);
        
        int channels = quality.channels;
        int sampleRate = quality.sampleRate;
        int bitsPerSample = quality.bitDepth;
        
        // Write WAV header (44 bytes)
        fos.write("RIFF".getBytes());
        fos.write(intToByteArray(0)); // File size (placeholder)
        fos.write("WAVE".getBytes());
        fos.write("fmt ".getBytes());
        fos.write(intToByteArray(16)); // Subchunk size
        fos.write(shortToByteArray((short) 1)); // Audio format (PCM)
        fos.write(shortToByteArray((short) channels));
        fos.write(intToByteArray(sampleRate));
        fos.write(intToByteArray(sampleRate * channels * bitsPerSample / 8)); // Byte rate
        fos.write(shortToByteArray((short) (channels * bitsPerSample / 8))); // Block align
        fos.write(shortToByteArray((short) bitsPerSample));
        fos.write("data".getBytes());
        fos.write(intToByteArray(0)); // Data size (placeholder)
        
        fos.close();
    }
    
    private void writeWavData(AudioQuality quality, int bufferSize) {
        byte[] buffer = new byte[bufferSize];
        
        try {
            FileOutputStream fos = new FileOutputStream(currentRecordingPath, true);
            
            while (isRecordingLossless) {
                int bytesRead = audioRecord.read(buffer, 0, bufferSize);
                if (bytesRead > 0) {
                    fos.write(buffer, 0, bytesRead);
                }
            }
            
            fos.close();
            
            // Update WAV header with final file size
            updateWavHeader(currentRecordingPath);
            
        } catch (IOException e) {
            logger.error("Error writing WAV data", e);
        }
    }
    
    private void updateWavHeader(String filePath) {
        try {
            RandomAccessFile raf = new RandomAccessFile(filePath, "rw");
            long fileSize = raf.length();
            
            // Update file size in RIFF header
            raf.seek(4);
            raf.write(intToByteArray((int) (fileSize - 8)));
            
            // Update data chunk size
            raf.seek(40);
            raf.write(intToByteArray((int) (fileSize - 44)));
            
            raf.close();
        } catch (IOException e) {
            logger.error("Error updating WAV header", e);
        }
    }
    
    private byte[] intToByteArray(int value) {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value).array();
    }
    
    private byte[] shortToByteArray(short value) {
        return ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(value).array();
    }
    
    private AudioQuality getAudioQuality() {
        String qualitySetting = settings.getString("audio_quality", "Ultra (Lossless)");
        
        if (qualitySetting.contains("Low")) {
            return new AudioQuality("Low", 64000, 44100, 1, false, 16);
        } else if (qualitySetting.contains("Standard")) {
            return new AudioQuality("Standard", 128000, 44100, 2, false, 16);
        } else if (qualitySetting.contains("High")) {
            return new AudioQuality("High", 192000, 48000, 2, false, 16);
        } else if (qualitySetting.contains("Professional")) {
            return new AudioQuality("Professional", 320000, 48000, 2, false, 16);
        } else if (qualitySetting.contains("Ultra (AAC)")) {
            return new AudioQuality("Ultra (AAC)", 320000, 96000, 2, false, 16);
        } else if (qualitySetting.contains("Ultra (Lossless)")) {
            // Lossless 96kHz 24-bit WAV
            return new AudioQuality("Ultra (Lossless)", 0, 96000, 2, true, 24);
        } else if (qualitySetting.contains("Studio Master")) {
            // Lossless 192kHz 24-bit WAV - absolute maximum quality
            return new AudioQuality("Studio Master", 0, 192000, 2, true, 24);
        } else {
            // Default: Ultra Lossless
            return new AudioQuality("Ultra (Lossless)", 0, 96000, 2, true, 24);
        }
    }
    
    private static class AudioQuality {
        String name;
        int bitrate;
        int sampleRate;
        int channels;
        boolean lossless;
        int bitDepth;
        
        AudioQuality(String name, int bitrate, int sampleRate, int channels, boolean lossless, int bitDepth) {
            this.name = name;
            this.bitrate = bitrate;
            this.sampleRate = sampleRate;
            this.channels = channels;
            this.lossless = lossless;
            this.bitDepth = bitDepth;
        }
    }

    private void stopRecording() {
        if (isRecording) {
            try {
                if (isRecordingLossless && audioRecord != null) {
                    // Stop lossless recording
                    isRecordingLossless = false;
                    
                    if (recordingThread != null) {
                        try {
                            recordingThread.join(1000); // Wait up to 1 second
                        } catch (InterruptedException e) {
                            logger.error("Recording thread interrupted", e);
                        }
                    }
                    
                    audioRecord.stop();
                    audioRecord.release();
                    audioRecord = null;
                    
                } else if (mediaRecorder != null) {
                    // Stop compressed recording
                    mediaRecorder.stop();
                    mediaRecorder.release();
                    mediaRecorder = null;
                }
                
                isRecording = false;
                
                // Calculate recording duration
                long duration = (System.currentTimeMillis() - recordingStartTime) / 1000;
                
                // Get file size
                File recordedFile = new File(currentRecordingPath);
                long fileSizeMB = recordedFile.length() / (1024 * 1024);
                
                Utils.showToast(String.format(Locale.US, 
                    "⏹️ Recording stopped (%s) - %d MB", 
                    formatDuration((int) duration), 
                    fileSizeMB));
                    
            } catch (Exception e) {
                logger.error("Failed to stop recording", e);
                Utils.showToast("❌ Error stopping recording");
            }
        }
    }

    private void sendVoiceMessage() {
        if (currentRecordingPath != null) {
            File audioFile = new File(currentRecordingPath);
            if (audioFile.exists()) {
                try {
                    // Get the current channel ID
                    long channelId = StoreStream.getChannelsSelected().getId();
                    
                    if (channelId == 0) {
                        Utils.showToast("No channel selected");
                        return;
                    }

                    // Create URI for the file
                    Uri fileUri = Uri.fromFile(audioFile);
                    
                    // Get file info
                    long fileSize = audioFile.length();
                    String fileName = audioFile.getName();
                    boolean isLossless = fileName.endsWith(".wav");
                    
                    // Get duration of the audio file
                    MediaPlayer mp = new MediaPlayer();
                    mp.setDataSource(currentRecordingPath);
                    mp.prepare();
                    int duration = mp.getDuration() / 1000; // Convert to seconds
                    mp.release();
                    
                    // Create message content with voice message info
                    String format = isLossless ? "WAV (Lossless)" : "AAC";
                    String sizeInfo = String.format(Locale.US, "%.1f MB", fileSize / (1024.0 * 1024.0));
                    String messageContent = String.format(Locale.US,
                        "🎤 Voice Message (%s) - %s | %s",
                        formatDuration(duration),
                        format,
                        sizeInfo
                    );
                    
                    // Upload the file to Discord
                    Utils.threadPool.execute(() -> {
                        try {
                            // Create the attachment list
                            List<RestAPI.Message.Attachment> attachments = new ArrayList<>();
                            RestAPI.Message.Attachment attachment = new RestAPI.Message.Attachment(
                                fileUri,
                                fileName,
                                "audio/mp4",
                                fileSize
                            );
                            attachments.add(attachment);
                            
                            // Send the message with the attachment
                            RestAPI.getApi().sendMessage(
                                channelId,
                                messageContent,
                                null,
                                null,
                                attachments,
                                null,
                                null
                            ).subscribe(
                                message -> {
                                    Utils.showToast("Voice message sent!");
                                    // Clean up the file after successful upload
                                    audioFile.delete();
                                },
                                error -> {
                                    logger.error("Failed to send voice message", error);
                                    Utils.showToast("Failed to send voice message");
                                }
                            );
                            
                        } catch (Exception e) {
                            logger.error("Error uploading file", e);
                            Utils.showToast("Failed to upload voice message");
                        }
                    });
                    
                } catch (Exception e) {
                    logger.error("Failed to send voice message", e);
                    Utils.showToast("Failed to send voice message");
                }
            }
        }
    }
    
    private String formatDuration(int seconds) {
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format(Locale.US, "%d:%02d", minutes, remainingSeconds);
    }

    private void playVoiceMessage(String filePath) {
        try {
            if (isPlaying) {
                stopPlayback();
                return;
            }

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(filePath);
            mediaPlayer.prepare();
            mediaPlayer.start();
            isPlaying = true;

            mediaPlayer.setOnCompletionListener(mp -> {
                stopPlayback();
            });

            Utils.showToast("Playing voice message...");
        } catch (IOException e) {
            logger.error("Failed to play voice message", e);
            Utils.showToast("Failed to play voice message");
        }
    }

    private void stopPlayback() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                mediaPlayer.release();
                mediaPlayer = null;
                isPlaying = false;
            } catch (Exception e) {
                logger.error("Failed to stop playback", e);
            }
        }
    }

    @Override
    public void stop(Context context) {
        // Clean up resources
        stopRecording();
        stopPlayback();
        patcher.unpatchAll();
    }
}
