package com.aliucord.plugins;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aliucord.PluginManager;
import com.aliucord.Utils;
import com.aliucord.api.SettingsAPI;
import com.aliucord.fragments.SettingsPage;
import com.aliucord.views.Button;
import com.aliucord.widgets.BottomSheet;

/**
 * Settings page for the VoiceMessages plugin
 * 
 * Future configuration options could include:
 * - Audio quality/bitrate settings
 * - File format selection
 * - Maximum recording duration
 * - Auto-send vs manual send
 * - Button placement customization
 */
public class VoiceMessagesSettings extends SettingsPage {
    private final SettingsAPI settings;
    
    public VoiceMessagesSettings(SettingsAPI settingsAPI) {
        this.settings = settingsAPI;
    }
    
    @Override
    public void onViewBound(View view) {
        super.onViewBound(view);
        setActionBarTitle("VoiceMessages Settings");
        
        LinearLayout layout = new LinearLayout(view.getContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        
        // Audio Quality Setting
        addHeader(layout, "Audio Quality");
        addQualitySelector(layout);
        
        TextView qualityInfo = new TextView(view.getContext());
        qualityInfo.setText("Current: Ultra (Lossless) - 96kHz/24-bit WAV\n\nLossless formats provide perfect audio quality with no compression artifacts.\n\nHigher quality = larger file sizes\nLossless files are 10-20x larger than compressed formats.");
        qualityInfo.setPadding(50, 10, 50, 20);
        qualityInfo.setTextSize(12);
        qualityInfo.setTextColor(0xFF9E9E9E);
        layout.addView(qualityInfo);
            
        // Recording Duration Setting
        addHeader(layout, "Recording");
        addSetting(layout, "Maximum Duration",
            "Current: Unlimited",
            "Set maximum recording length");
            
        // Behavior Settings
        addHeader(layout, "Behavior");
        addToggleSetting(layout, "Auto-send", 
            "send_immediately",
            "Send voice message immediately after stopping recording");
        
        addToggleSetting(layout, "Delete after send",
            "delete_after_send", 
            "Delete local file after successful upload");
            
        // About section
        addHeader(layout, "About");
        TextView aboutText = new TextView(view.getContext());
        String currentQuality = settings.getString("audio_quality", "Ultra (Lossless)");
        aboutText.setText(
            "VoiceMessages v1.0.0\n\n" +
            "Record and send ultra-high quality voice messages.\n\n" +
            "Current Quality: " + currentQuality + "\n\n" +
            "File Size Estimates (per minute):\n" +
            "• Low: ~480 KB\n" +
            "• Standard: ~960 KB\n" +
            "• High: ~1.4 MB\n" +
            "• Professional: ~2.4 MB\n" +
            "• Ultra (AAC): ~2.9 MB\n" +
            "• Ultra (Lossless): ~27 MB\n" +
            "• Studio Master: ~55 MB\n\n" +
            "Lossless = Perfect quality, NO compression!\n\n" +
            "Developed for Aliucord"
        );
        aboutText.setPadding(50, 20, 50, 20);
        aboutText.setTextSize(13);
        layout.addView(aboutText);
        
        addView(layout);
    }
    
    private void addQualitySelector(LinearLayout layout) {
        String[] qualities = {
            "Low (64 kbps)",
            "Standard (128 kbps)", 
            "High (192 kbps)", 
            "Professional (320 kbps)",
            "Ultra (AAC) - 96kHz",
            "Ultra (Lossless) - 96kHz/24-bit",
            "Studio Master - 192kHz/24-bit"
        };
        String currentQuality = settings.getString("audio_quality", "Ultra (Lossless)");
        
        for (String quality : qualities) {
            LinearLayout qualityLayout = new LinearLayout(layout.getContext());
            qualityLayout.setOrientation(LinearLayout.HORIZONTAL);
            qualityLayout.setPadding(50, 15, 50, 15);
            
            TextView qualityText = new TextView(layout.getContext());
            qualityText.setText(quality);
            qualityText.setTextSize(15);
            
            boolean isSelected = currentQuality.contains(quality.split(" - ")[0].replace(" (AAC)", ""));
            if (isSelected) {
                qualityText.setTextColor(0xFF3BA55D); // Green for selected
                qualityText.setText(quality + " ✓");
            }
            
            qualityLayout.addView(qualityText);
            qualityLayout.setOnClickListener(v -> {
                settings.setString("audio_quality", quality);
                Utils.showToast("Quality set to: " + quality + "\n(Requires plugin restart)");
            });
            
            layout.addView(qualityLayout);
        }
    }
    
    private void addHeader(LinearLayout layout, String text) {
        TextView header = new TextView(layout.getContext());
        header.setText(text);
        header.setTextSize(18);
        header.setPadding(50, 40, 50, 20);
        header.setTextColor(0xFF9E9E9E);
        layout.addView(header);
    }
    
    private void addSetting(LinearLayout layout, String title, String subtitle, String description) {
        LinearLayout settingLayout = new LinearLayout(layout.getContext());
        settingLayout.setOrientation(LinearLayout.VERTICAL);
        settingLayout.setPadding(50, 20, 50, 20);
        
        TextView titleView = new TextView(layout.getContext());
        titleView.setText(title);
        titleView.setTextSize(16);
        settingLayout.addView(titleView);
        
        TextView subtitleView = new TextView(layout.getContext());
        subtitleView.setText(subtitle);
        subtitleView.setTextSize(12);
        subtitleView.setTextColor(0xFF9E9E9E);
        settingLayout.addView(subtitleView);
        
        settingLayout.setOnClickListener(v -> {
            Utils.showToast(description + " (Coming soon)");
        });
        
        layout.addView(settingLayout);
    }
    
    private void addToggleSetting(LinearLayout layout, String title, String key, String description) {
        LinearLayout settingLayout = new LinearLayout(layout.getContext());
        settingLayout.setOrientation(LinearLayout.HORIZONTAL);
        settingLayout.setPadding(50, 20, 50, 20);
        
        LinearLayout textLayout = new LinearLayout(layout.getContext());
        textLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            1.0f
        );
        textLayout.setLayoutParams(textParams);
        
        TextView titleView = new TextView(layout.getContext());
        titleView.setText(title);
        titleView.setTextSize(16);
        textLayout.addView(titleView);
        
        TextView descView = new TextView(layout.getContext());
        descView.setText(description);
        descView.setTextSize(12);
        descView.setTextColor(0xFF9E9E9E);
        textLayout.addView(descView);
        
        settingLayout.addView(textLayout);
        
        // Add switch/toggle here when implemented
        Button toggleButton = new Button(layout.getContext());
        boolean currentValue = settings.getBool(key, true);
        toggleButton.setText(currentValue ? "ON" : "OFF");
        toggleButton.setOnClickListener(v -> {
            boolean newValue = !settings.getBool(key, true);
            settings.setBool(key, newValue);
            toggleButton.setText(newValue ? "ON" : "OFF");
            Utils.showToast(title + ": " + (newValue ? "Enabled" : "Disabled"));
        });
        
        settingLayout.addView(toggleButton);
        layout.addView(settingLayout);
    }
}
